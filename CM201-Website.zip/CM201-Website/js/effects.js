/* CM201 - effets : GSAP + ScrollTrigger, Lenis (synchronisé au ticker GSAP),
   et versions vanilla des composants React Bits : BlurText, LightRays, StarBorder, CountUp. */
(()=>{
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
const hasG=!!(window.gsap&&window.ScrollTrigger);
if(hasG)gsap.registerPlugin(ScrollTrigger);

/* ---- Lenis + GSAP ticker ---- */
if(!reduce&&hasG&&window.Lenis){
 const lenis=new Lenis({autoRaf:false,lerp:.1,smoothWheel:true});window.lenis=lenis;
 lenis.on('scroll',ScrollTrigger.update);
 gsap.ticker.add(t=>lenis.raf(t*1000));gsap.ticker.lagSmoothing(0);
 document.addEventListener('click',e=>{const a=e.target.closest('a[href^="#"]');if(!a)return;const id=a.getAttribute('href');if(id.length<2)return;
  const t=id==='#home'?0:$(id);if(t==null)return;e.preventDefault();lenis.scrollTo(t,{offset:t===0?0:-68,duration:1.3})});
}

/* ---- StarBorder (bouton principal du hero) ---- */
const pb=$('.hero-t a.btn');
if(pb){const w=document.createElement('span');w.className='star-border';w.innerHTML='<i class="sb-b"></i><i class="sb-t"></i>';pb.before(w);w.appendChild(pb)}

/* ---- LightRays (WebGL, couleurs caramel) ---- */
function lightRays(){
 const home=$('#home');if(!home)return;
 const cv=document.createElement('canvas');cv.className='lightrays';cv.setAttribute('aria-hidden','true');
 const gl=cv.getContext('webgl',{alpha:true,premultipliedAlpha:true});if(!gl)return;
 const vs='attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';
 const fs=`#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec2 R;uniform float T;uniform vec2 S;uniform vec2 D;uniform vec3 C;uniform vec2 M;
float ray(vec2 src,vec2 dir,vec2 co,float a,float b,float sp){
 vec2 d=co-src;float L=length(d);vec2 n=d/max(L,1e-4);float ca=dot(n,dir);
 float spread=pow(max(ca,0.0),1.0/0.8);
 float maxD=R.x*1.2;float lf=clamp((maxD-L)/maxD,0.,1.);
 float ff=clamp((R.x-L)/R.x,0.5,1.);
 float base=clamp((0.45+0.15*sin(ca*a+T*sp))+(0.3+0.2*cos(-ca*b+T*sp)),0.,1.);
 return base*lf*ff*spread;}
void main(){vec2 co=vec2(gl_FragCoord.x,R.y-gl_FragCoord.y);
 vec2 fd=normalize(mix(D,normalize(M*R-S),0.08));
 float r=ray(S,fd,co,36.2214,21.11349,0.9)*.5+ray(S,fd,co,22.3991,18.0234,0.66)*.4;
 r*=0.1+(1.-co.y/R.y)*0.8;
 r*=1.6;gl_FragColor=vec4(C*r,r);}`;
 const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);return gl.getShaderParameter(o,gl.COMPILE_STATUS)?o:null};
 const v=sh(gl.VERTEX_SHADER,vs),f=sh(gl.FRAGMENT_SHADER,fs);if(!v||!f)return;
 const pr=gl.createProgram();gl.attachShader(pr,v);gl.attachShader(pr,f);gl.linkProgram(pr);if(!gl.getProgramParameter(pr,gl.LINK_STATUS))return;
 gl.useProgram(pr);gl.bindBuffer(gl.ARRAY_BUFFER,gl.createBuffer());gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
 const loc=gl.getAttribLocation(pr,'p');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
 const U=n=>gl.getUniformLocation(pr,n);const u={R:U('R'),T:U('T'),S:U('S'),D:U('D'),C:U('C'),M:U('M')};
 home.insertBefore(cv,home.firstChild);
 const col=[0xe0/255,0xa8/255,0x60/255];let mx=.5,my=.3,sx=.5,sy=.3,vis=true,t0=performance.now();
 const size=()=>{const k=.55;cv.width=Math.max(2,Math.round(home.clientWidth*k));cv.height=Math.max(2,Math.round(home.clientHeight*k));gl.viewport(0,0,cv.width,cv.height)};
 const draw=t=>{sx+=(mx-sx)*.04;sy+=(my-sy)*.04;gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);
  gl.uniform2f(u.R,cv.width,cv.height);gl.uniform1f(u.T,t);gl.uniform2f(u.S,.72*cv.width,-.2*cv.height);gl.uniform2f(u.D,0,1);gl.uniform3f(u.C,col[0],col[1],col[2]);gl.uniform2f(u.M,sx,sy);gl.drawArrays(gl.TRIANGLES,0,3)};
 size();addEventListener('resize',()=>{size();draw(reduce?3:(performance.now()-t0)/1000)});
 if(reduce){draw(3);return}
 addEventListener('pointermove',e=>{mx=e.clientX/innerWidth;my=e.clientY/innerHeight},{passive:true});
 new IntersectionObserver(e=>vis=e[0].isIntersecting).observe(home);
 (function loop(){requestAnimationFrame(loop);if(!vis||document.hidden)return;draw((performance.now()-t0)/1000)})();
}
try{lightRays()}catch(e){}

if(!hasG)return;

/* ---- BlurText (titre du hero) ---- */
const h1=$('.hero-t h1');let words=[];
const heroRest='.hero-t p,.hero-t .star-border,.hero-t .btn.ghost';
if(h1&&!reduce){
 const txt=h1.textContent.trim();h1.textContent='';
 txt.split(' ').forEach((w,i,a)=>{const s=document.createElement('span');s.textContent=w;s.style.cssText='display:inline-block;will-change:transform,filter,opacity';h1.appendChild(s);if(i<a.length-1)h1.appendChild(document.createTextNode(' '));words.push(s)});
 gsap.set(words,{filter:'blur(10px)',opacity:0,y:-18});gsap.set(heroRest,{opacity:0,y:14});
}
let started=false;
function go(){if(started)return;started=true;if(reduce||!words.length)return;
 gsap.to(words,{keyframes:[{filter:'blur(4px)',opacity:.5,y:4,duration:.35},{filter:'blur(0px)',opacity:1,y:0,duration:.35}],stagger:.12,ease:'power2.out',onComplete:()=>gsap.set(words,{clearProps:'filter,willChange'})});
 gsap.to(heroRest,{opacity:1,y:0,duration:.8,stagger:.12,ease:'power2.out',delay:.6,clearProps:'transform,opacity'});
}
addEventListener('cm201:ready',go);setTimeout(go,5000);

if(reduce)return;

/* ---- Apparition des sections ---- */
const SEL='section h2,section .lead,.vals>div,.about-art,.tabs,.offer,.tst blockquote,#reserve form,#ctForm,.news .wrap>*,#contact .two>div:first-child p,#contact .map';
gsap.set(SEL,{opacity:0,y:26});
ScrollTrigger.batch(SEL,{start:'top 90%',once:true,onEnter:b=>gsap.to(b,{opacity:1,y:0,duration:.9,ease:'power2.out',stagger:.09,overwrite:true,clearProps:'transform,opacity'})});

/* ---- CountUp (prix) ---- */
function counter(el){const m=el.textContent.match(/^(\d+)(.*)$/);if(!m)return;const to=+m[1],suf=m[2],o={n:0};el.textContent='0'+suf;
 ScrollTrigger.create({trigger:el,start:'top 92%',once:true,onEnter:()=>gsap.to(o,{n:to,duration:1.3,ease:'power1.out',onUpdate:()=>{el.textContent=Math.round(o.n)+suf},onComplete:()=>{el.textContent=m[0]}})});}
$$('.offer s,.offer strong').forEach(counter);

/* ---- Cartes du menu (re-rendues à chaque onglet) ---- */
let cardST=[];
function revealCards(){const cs=$$('#grid .card');cardST.forEach(s=>s.kill());
 gsap.set(cs,{opacity:0,y:26});
 cardST=ScrollTrigger.batch(cs,{start:'top 92%',once:true,onEnter:b=>gsap.to(b,{opacity:1,y:0,duration:.8,ease:'power2.out',stagger:.07,overwrite:true,clearProps:'transform,opacity'})});
 $$('#grid .price').forEach(counter);}
revealCards();
if(typeof window.show==='function'){const _s=window.show;window.show=function(c){_s(c);revealCards();ScrollTrigger.refresh()}}
addEventListener('load',()=>ScrollTrigger.refresh());
})();
