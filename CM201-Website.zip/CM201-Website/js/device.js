/* CM201 - adaptation appareil : classes iOS/Android, onglets mobiles, gestes tactiles */
(()=>{
const d=document.documentElement,ua=navigator.userAgent;
const ios=/iPhone|iPad|iPod/.test(ua)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
d.classList.add(ios?'ios':/Android/i.test(ua)?'android':'desk');
if(matchMedia('(hover:none)').matches)d.classList.add('touch');
const $=s=>document.querySelector(s);
/* badge panier synchronisé */
const c=$('#cnt'),b=$('#cnt2');
if(c&&b){const s=()=>{b.textContent=c.textContent;b.classList.toggle('z',c.textContent.trim()==='0')};s();new MutationObserver(s).observe(c,{childList:true,characterData:true,subtree:true})}
const tc=$('#tabCart');if(tc)tc.addEventListener('click',()=>openC(1));
/* onglet actif selon la section visible */
const tabs=[...document.querySelectorAll('.tabbar [data-t]')];
const act=()=>{let cur='home';['menu','reserve'].forEach(k=>{const e=$('#'+k);if(e&&e.getBoundingClientRect().top<=innerHeight*.4)cur=k});tabs.forEach(t=>t.classList.toggle('on',t.dataset.t===cur))};
addEventListener('scroll',act,{passive:true});act();
/* balayage horizontal dans la visionneuse */
const lb=$('#lb');let x0=null;
lb.addEventListener('touchstart',e=>{x0=e.touches[0].clientX},{passive:true});
lb.addEventListener('touchend',e=>{if(x0==null)return;const dx=e.changedTouches[0].clientX-x0;x0=null;if(Math.abs(dx)>50)$(dx<0?'#lbn':'#lbp').click()},{passive:true});
/* glisser vers le bas pour fermer le panier (feuille mobile) */
const dr=$('#drawer');let y0=null;
dr.addEventListener('touchstart',e=>{if(innerWidth<=700&&dr.scrollTop===0)y0=e.touches[0].clientY},{passive:true});
dr.addEventListener('touchend',e=>{if(y0==null)return;const dy=e.changedTouches[0].clientY-y0;y0=null;if(dy>90)openC(0)},{passive:true});
})();
