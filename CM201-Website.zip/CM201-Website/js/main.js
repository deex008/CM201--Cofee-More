/* ---------- DATA ---------- */
const P=[
{id:'esp',c:'coffee',n:'Espresso',p:15,d:'Intense, crémeux, torréfaction maison.',col:'#3b1d0e',foam:'#c68a4d'},
{id:'cap',c:'coffee',n:'Cappuccino',p:22,d:'Espresso, lait vapeur, mousse veloutée.',col:'#8a5a35',foam:'#f1e3cf'},
{id:'lat',c:'coffee',n:'Café Latte',p:25,d:'Onctueux et doux, finition latte art.',col:'#b98b5a',foam:'#f6efe4'},
{id:'ice',c:'coffee',n:'Iced Coffee',p:28,d:'Glaçons, espresso et crème fraîche.',col:'#6b3d22',foam:'#d9b98a',ice:1},
{id:'moc',c:'coffee',n:'Mocha',p:27,d:'Espresso, chocolat noir, crème.',col:'#4a2a1a',foam:'#e6d6bd'},
{id:'chk',c:'dessert',n:'Cheesecake',p:30,d:'Crémeux, coulis de fruits rouges.',t:'slice'},
{id:'brw',c:'dessert',n:'Chocolate Brownie',p:25,d:'Fondant, noix et chocolat noir.',t:'brownie'},
{id:'crs',c:'dessert',n:'Croissant',p:12,d:'Pur beurre, doré à la perfection.',t:'croissant'},
{id:'tir',c:'dessert',n:'Tiramisu',p:32,d:'Mascarpone, café et cacao.',t:'tiramisu'}];
const O=[
{id:'o1',n:'Coffee + Croissant',d:'Un Espresso et un Croissant pur beurre.',old:27,p:24},
{id:'o2',n:'Breakfast Combo',d:'Café Latte, Croissant et Brownie.',old:62,p:49},
{id:'o3',n:'Coffee + Dessert',d:'Un Cappuccino et une part de Cheesecake.',old:52,p:45}];
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
function art(x){
 if(x.col)return `<svg viewBox="0 0 120 120"><ellipse cx="60" cy="100" rx="48" ry="10" fill="#e6d6bd"/><ellipse cx="60" cy="98" rx="48" ry="9" fill="#fff" opacity=".5"/><path d="M26 48h62l-6 40q-3 10-25 10t-25-10z" fill="${x.ice?'#f6efe4':'#fff'}" stroke="#d9c8ae"/><path d="M88 56q22 0 18 18t-26 14" fill="none" stroke="#fff" stroke-width="7"/><ellipse cx="57" cy="48" rx="31" ry="8" fill="${x.col}"/><ellipse cx="57" cy="48" rx="20" ry="5" fill="${x.foam}"/>${x.ice?'<rect x="44" y="40" width="12" height="10" rx="2" fill="#fff" opacity=".7"/><rect x="60" y="38" width="12" height="10" rx="2" fill="#fff" opacity=".6"/>':''}</svg>`;
 const T={slice:'<path d="M14 84L108 70 100 38z" fill="#f4dfb0"/><path d="M14 84L108 70v14L14 100z" fill="#c9985a"/><path d="M100 38L108 70" stroke="#d9b98a"/><circle cx="60" cy="56" r="8" fill="#a3203a"/>',
 brownie:'<path d="M20 60l52-16 34 14-52 20z" fill="#5a2f1a"/><path d="M20 60v22l36 16V78z" fill="#2f170c"/><path d="M56 78l50-20v22L56 98z" fill="#3d200f"/><circle cx="62" cy="58" r="5" fill="#b98b5a"/>',
 croissant:'<path d="M12 78q8-40 48-42t48 42q-14-14-24-14l-24 6-24-6q-10 0-24 14z" fill="#d79a4e"/><path d="M36 52l8 24M60 44v26M84 52l-8 24" stroke="#a96b2a" stroke-width="3"/>',
 tiramisu:'<path d="M20 50h80v46H20z" fill="#f1e3cf"/><path d="M20 70h80v8H20z" fill="#7a4a2c"/><path d="M20 50h80v10H20z" fill="#4a2a1a"/><path d="M20 50l14-12h66l-0 12z" fill="#6b3d22"/>'};
 return `<svg viewBox="0 0 120 120">${T[x.t]}</svg>`}

/* ---------- CART ---------- */
/* >>> Numéro WhatsApp du café (format international, sans + ni espaces) <<< */
const WA='212600000000';
let cart={};try{cart=JSON.parse(localStorage.getItem('cm201cart')||'{}')||{}}catch(e){cart={}}
let L={};[...P,...O].forEach(x=>L[x.id]=x);Object.keys(cart).forEach(k=>{if(!L[k]||!(cart[k]>0))delete cart[k]});
const fmt=n=>n+' MAD';
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.k);toast.k=setTimeout(()=>t.classList.remove('show'),2200)}
function add(id){cart[id]=(cart[id]||0)+1;draw();toast(L[id].n+' ajouté au panier')}
function chg(id,d){cart[id]+=d;if(cart[id]<=0)delete cart[id];draw()}
function draw(){
 const ids=Object.keys(cart);let tot=0,n=0;
 $('#items').innerHTML=ids.length?ids.map(i=>{const x=L[i];tot+=x.p*cart[i];n+=cart[i];return `<div class="item"><strong>${x.n}</strong><span>${fmt(x.p*cart[i])}</span><div class="qty"><button aria-label="Moins" onclick="chg('${i}',-1)">−</button>${cart[i]}<button aria-label="Plus" onclick="chg('${i}',1)">+</button></div><span></span></div>`}).join(''):'<p style="opacity:.6;margin-top:16px">Votre panier est vide. Choisissez un café dans le menu.</p>';
 try{localStorage.setItem('cm201cart',JSON.stringify(cart))}catch(e){}
 $('#waBtn').style.display=ids.length?'':'none';
 $('#total').textContent=fmt(tot);$('#cnt').textContent=n;
 $('#goPay').style.display=ids.length&&$('#payForm').style.display==='none'?'':'none';
 if(!ids.length)$('#payForm').style.display='none'}
const openC=o=>{window.lenis&&(o?lenis.stop():lenis.start());$('#drawer').classList.toggle('open',o);$('#veil').classList.toggle('open',o)};
$('#openCart').onclick=()=>openC(1);$('#closeCart').onclick=$('#veil').onclick=()=>openC(0);
$('#waBtn').onclick=()=>{const ids=Object.keys(cart);if(!ids.length)return;let t=0;const lines=ids.map(i=>{t+=L[i].p*cart[i];return `• ${cart[i]} x ${L[i].n} : ${fmt(L[i].p*cart[i])}`});window.open(`https://wa.me/${WA}?text=${encodeURIComponent('Bonjour CM201 ! Je souhaite commander :\n'+lines.join('\n')+'\nTotal : '+fmt(t)+'\nMerci !')}`,'_blank','noopener')};
['#waLink','#waSticky'].forEach(s=>{$(s).href=`https://wa.me/${WA}?text=${encodeURIComponent('Bonjour CM201 !')}`});
$('#goPay').onclick=()=>{$('#payForm').style.display='grid';$('#goPay').style.display='none'};
$('#payForm').onsubmit=e=>{e.preventDefault();const nm=e.target.n.value;for(const k in cart)delete cart[k];e.target.reset();e.target.style.display='none';draw();
 $('#items').innerHTML=`<div class="ok show">Merci ${nm} ! Commande n°CM${Math.floor(1000+Math.random()*9000)} confirmée. Livraison estimée : 30 min.</div>`}

/* ---------- MENU ---------- */
function show(c){$('#grid').innerHTML=P.filter(x=>x.c===c).map(x=>`<div class="card">${art(x)}<h3>${x.n}</h3><small>${x.d}</small><div class="price">${fmt(x.p)}</div><button class="btn" onclick="add('${x.id}')">Ajouter</button></div>`).join('');
 $$('.card').forEach(k=>{k.onmousemove=e=>{const r=k.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;k.style.transform=`perspective(700px) rotateY(${x*12}deg) rotateX(${-y*12}deg) translateY(-6px)`};k.onmouseleave=()=>k.style.transform=''})}
$$('.tab').forEach(t=>t.onclick=()=>{$$('.tab').forEach(b=>b.classList.remove('on'));t.classList.add('on');show(t.dataset.c)});show('coffee');
$('#offerBox').innerHTML=O.map(o=>`<div class="offer"><h3>${o.n}</h3><p>${o.d}</p><s>${fmt(o.old)}</s><strong>${fmt(o.p)}</strong><button class="btn" onclick="add('${o.id}')">Profiter de l'offre</button></div>`).join('');
$('[data-order]').onclick=()=>openC(0);

/* ---------- FORMS / NAV ---------- */
$('#dt').min=new Date().toISOString().split('T')[0];
$('#resForm').onsubmit=e=>{e.preventDefault();const f=e.target;const o=$('#resOk');o.textContent=`Merci ${f.n.value} ! Table pour ${f.g.value} personne(s) réservée le ${f.d.value} à ${f.h.value}. Confirmation au ${f.t.value}.`;o.classList.add('show');f.reset()};
$('#newsForm').onsubmit=e=>{e.preventDefault();toast('Bienvenue chez CM201 ! Inscription confirmée.');e.target.reset()};
$('#ctForm').onsubmit=e=>{e.preventDefault();$('#ctOk').classList.add('show');e.target.reset()};
$('#burger').onclick=()=>$('#links').classList.toggle('open');
$$('#links a').forEach(a=>a.onclick=()=>$('#links').classList.remove('open'));
addEventListener('scroll',()=>$('#nav').classList.toggle('solid',scrollY>60),{passive:true});

/* ---------- 3D HERO ---------- */
function hero(){
 const cv=$('#stage'),mobile=Math.min(innerWidth,innerHeight)<700||matchMedia('(pointer:coarse)').matches;
 let R;try{R=new THREE.WebGLRenderer({canvas:cv,antialias:!mobile,alpha:true})}catch(e){$('#fb').style.display='block';return}
 R.setPixelRatio(Math.min(devicePixelRatio,mobile?1.5:2));R.shadowMap.enabled=!mobile;R.shadowMap.type=THREE.PCFSoftShadowMap;
 R.toneMapping=THREE.ACESFilmicToneMapping;R.toneMappingExposure=1.15;R.outputEncoding=THREE.sRGBEncoding;
 const S=new THREE.Scene(),C=new THREE.PerspectiveCamera(32,1,.1,100);
 const key=new THREE.DirectionalLight(0xffe2b8,1.7);key.position.set(4,7,5);key.castShadow=!mobile;key.shadow.mapSize.set(1024,1024);
 Object.assign(key.shadow.camera,{left:-4,right:4,top:4,bottom:-4});S.add(key);
 const rim=new THREE.PointLight(0xc0833f,2.5,20);rim.position.set(-5,3,-3);S.add(rim);
 S.add(new THREE.HemisphereLight(0xfff0dd,0x3a1e10,.7));
 const G=new THREE.Group();S.add(G);
 const ceramic=new THREE.MeshPhysicalMaterial({color:0xfaf4ea,roughness:.18,clearcoat:1,clearcoatRoughness:.05,side:THREE.DoubleSide});
 const lathe=pts=>new THREE.Mesh(new THREE.LatheGeometry(pts.map(p=>new THREE.Vector2(p[0],p[1])),72),ceramic);
 const cup=lathe([[0,0],[.5,0],[.58,.06],[.85,.55],[1.08,1.15],[1.12,1.18],[1.05,1.18],[1.02,1.12],[.82,.55],[.5,.14],[0,.14]]);
 const saucer=lathe([[0,0],[1.1,0],[1.6,.14],[1.75,.2],[1.7,.2],[1.55,.16],[1.05,.07],[0,.07]]);
 const handle=new THREE.Mesh(new THREE.TorusGeometry(.42,.085,20,40,Math.PI*1.25),ceramic);handle.position.set(1.0,.78,0);handle.rotation.z=-Math.PI*.62;
 cup.position.y=.16;handle.position.y+=.16;
 const coffee=new THREE.Mesh(new THREE.CircleGeometry(1.03,64),new THREE.MeshPhysicalMaterial({color:0x2b1409,roughness:.12,clearcoat:1}));
 coffee.rotation.x=-Math.PI/2;coffee.position.y=1.17;
 const crema=new THREE.Mesh(new THREE.RingGeometry(.2,.95,64),new THREE.MeshStandardMaterial({color:0x9c5e30,roughness:.35,transparent:true,opacity:.55}));
 crema.rotation.x=-Math.PI/2;crema.position.y=1.175;
 [cup,saucer,handle].forEach(m=>{m.castShadow=true;m.receiveShadow=true});
 const cupG=new THREE.Group();cupG.add(cup,handle,coffee,crema);cupG.position.y=.12;G.add(saucer,cupG);
 const gnd=new THREE.Mesh(new THREE.PlaneGeometry(30,30),new THREE.ShadowMaterial({opacity:.4}));gnd.rotation.x=-Math.PI/2;gnd.position.y=-.01;gnd.receiveShadow=true;S.add(gnd);
 /* steam */
 const cc=document.createElement('canvas');cc.width=cc.height=64;const g=cc.getContext('2d'),gr=g.createRadialGradient(32,32,0,32,32,32);
 gr.addColorStop(0,'rgba(255,255,255,.9)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,64,64);
 const tex=new THREE.CanvasTexture(cc),steam=[];
 for(let i=0;i<(mobile?18:36);i++){const s=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false,opacity:0}));s.u={t:Math.random(),sp:.18+Math.random()*.12,ph:Math.random()*6.3,ox:(Math.random()-.5)*.6};G.add(s);steam.push(s)}
 /* beans */
 const bm=new THREE.MeshPhysicalMaterial({color:0x2e160b,roughness:.5,clearcoat:.4}),gm=new THREE.MeshBasicMaterial({color:0x140a05}),beans=[];
 for(let i=0;i<(mobile?7:16);i++){const b=new THREE.Group(),m=new THREE.Mesh(new THREE.SphereGeometry(.16,24,16),bm);m.scale.set(1,.68,.6);m.castShadow=!mobile;
  const gv=new THREE.Mesh(new THREE.BoxGeometry(.3,.012,.02),gm);gv.position.y=.108;gv.rotation.z=.12;b.add(m,gv);
  const a=Math.random()*6.28,r=2.3+Math.random()*1.8;b.position.set(Math.cos(a)*r,.4+Math.random()*3.2,Math.sin(a)*r*.6-.5);
  b.u={y:b.position.y,sp:.4+Math.random(),ph:Math.random()*6,rs:new THREE.Vector3(Math.random(),Math.random(),Math.random()).multiplyScalar(.01)};b.scale.setScalar(.8+Math.random()*.9);S.add(b);beans.push(b)}
 /* resize / input */
 let mx=0,my=0,sc=0;
 function size(){const w=cv.clientWidth,h=cv.clientHeight;R.setSize(w,h,false);C.aspect=w/h;const asp=w/h,wide=asp>1.1,z=wide?11.5:Math.max(11.5,2.6/(Math.tan(.2793)*asp));C.position.set(0,wide?3.6:z*.3,z);C.lookAt(wide?-1.2:0,1.1,0);C.setViewOffset(w,h,wide?-w*.1:0,wide?0:h*.27,w,h);}
 size();addEventListener('resize',size);
 addEventListener('pointermove',e=>{mx=e.clientX/innerWidth-.5;my=e.clientY/innerHeight-.5},{passive:true});
 addEventListener('scroll',()=>sc=Math.min(scrollY/innerHeight,1),{passive:true});
 const clk=new THREE.Clock();let vis=true;
 new IntersectionObserver(e=>vis=e[0].isIntersecting).observe(cv);
 (function loop(){requestAnimationFrame(loop);if(!vis)return;const t=clk.getElapsedTime();
  G.rotation.y+=((mx*1.2+t*.12+sc*2)-G.rotation.y)*.05;G.rotation.x+=((my*.25+sc*.3)-G.rotation.x)*.05;
  G.position.y=Math.sin(t*.8)*.06-sc*1.2;G.scale.setScalar(1-sc*.25);
  steam.forEach(s=>{const u=s.u;u.t+=u.sp*.012;if(u.t>1)u.t=0;const k=u.t;
   s.position.set(u.ox*.5+Math.sin(k*6+u.ph)*.18*k*2,1.35+k*2.4,Math.cos(k*5+u.ph)*.12);
   s.scale.setScalar(.35+k*1.1);s.material.opacity=Math.sin(k*Math.PI)*.2});
  beans.forEach(b=>{b.position.y=b.u.y+Math.sin(t*b.u.sp+b.u.ph)*.25-sc*.8+(my*-.3);b.rotation.x+=b.u.rs.x;b.rotation.y+=b.u.rs.y;b.rotation.z+=b.u.rs.z;b.position.x+=mx*.002});
  R.render(S,C)})();
}
/* ---------- GALLERY ---------- */
/* Photos optionnelles : images/01.jpg … images/12.jpg. Sinon une illustration s'affiche. */
const inn=x=>art(x).replace(/<\/?svg[^>]*>/g,'');
const rnd=n=>{const s=Math.sin(n*127.1)*43758.5;return s-Math.floor(s)};
const glow=(x,y,r)=>[1,.6,.3].map(k=>`<circle cx="${x}" cy="${y}" r="${r*k*1.6}" fill="#ffcf8a" opacity=".13"/>`).join('');
const person=(x,c)=>`<path d="M${x-55} 400v-110q0-45 55-45t55 45v110z" fill="${c}"/><circle cx="${x}" cy="190" r="32" fill="#d9b98a"/><path d="M${x-33} 185q33-52 66 0z" fill="#1d0e07"/>`;
const GAL=[
{r:0.66,R:0.563,cap:'Notre salon feutré',sub:'Lumières chaudes et bois sombre',bg:['#8a5230','#150a04'],b:()=>`<rect x="-300" y="290" width="1000" height="400" fill="#2a160d"/><rect x="40" y="250" width="320" height="50" rx="4" fill="#1a0c05"/><rect x="60" y="190" width="280" height="6" fill="#c0833f"/>${[90,130,170,230,270,310].map(x=>`<rect x="${x-8}" y="170" width="16" height="20" rx="3" fill="#f6efe4"/>`).join('')}${[90,200,310].map(x=>`<line x1="${x}" y1="-60" x2="${x}" y2="60" stroke="#1a0c05" stroke-width="2"/><path d="M${x-28} 90a28 28 0 0 1 56 0z" fill="#d9a05b"/>${glow(x,96,28)}`).join('')}${[100,200,300].map(x=>`<rect x="${x-7}" y="310" width="14" height="60" fill="#0e0602"/><ellipse cx="${x}" cy="308" rx="26" ry="7" fill="#c0833f"/>`).join('')}`},
{r:1.084,R:1.084,cap:'Espresso',sub:"L'extraction parfaite",bg:['#5b3320','#120804'],b:()=>`<ellipse cx="200" cy="290" rx="120" ry="28" fill="#f6efe4"/><g transform="translate(104 130) scale(1.6)">${inn(P[0])}</g><path d="M175 130q-18-26 0-48t0-40M215 130q-18-26 0-48t0-40" stroke="#fff" stroke-opacity=".35" stroke-width="7" fill="none" stroke-linecap="round"/>`},
{r:0.749,R:0.749,cap:'Latte art',sub:'Un cappuccino signé',bg:['#b98b5a','#3a1e10'],b:()=>`<circle cx="200" cy="200" r="150" fill="#f6efe4"/><path d="M310 200h44a16 16 0 0 1 0 32h-40" fill="none" stroke="#fff" stroke-width="14"/><circle cx="200" cy="200" r="112" fill="#fff"/><circle cx="200" cy="200" r="92" fill="#8a5a35"/><circle cx="200" cy="200" r="78" fill="#e9d7bd"/><path d="M200 262c-52-34-56-72-28-79 16-3 28 7 28 17 0-10 12-20 28-17 28 7 24 45-28 79z" fill="#8a5a35"/><path d="M200 245c-30-22-32-44-17-48 9-2 17 4 17 10 0-6 8-12 17-10 15 4 13 26-17 48z" fill="#f6efe4"/>`},
{r:1.0,R:1.0,cap:'Grains fraîchement torréfiés',sub:'Sélection single origin',bg:['#3a1e10','#0e0602'],b:()=>Array.from({length:46},(_,n)=>{const x=-40+rnd(n)*480,y=-40+rnd(n+90)*480,a=rnd(n+9)*360,s=.8+rnd(n+3)*.6;return `<g transform="translate(${x} ${y}) rotate(${a}) scale(${s})"><ellipse rx="30" ry="20" fill="#4a2616"/><ellipse rx="18" ry="7" cy="-8" fill="#8a5230" opacity=".5"/><path d="M-26 0q26-10 52 0" stroke="#140a05" stroke-width="4" fill="none"/></g>`}).join('')},
{r:0.848,R:0.848,cap:'Croissants pur beurre',sub:'Sortis du four ce matin',bg:['#e6c48f','#7a4a2c'],b:()=>`<ellipse cx="200" cy="300" rx="170" ry="34" fill="#f6efe4"/><g transform="translate(30 130) scale(1.9)">${inn(P[7])}</g><g transform="translate(130 70) scale(1.5)">${inn(P[7])}</g>`},
{r:0.75,R:0.75,cap:'Cheesecake et brownie fondant',sub:'Nos douceurs maison',bg:['#c9a273','#3a1e10'],b:()=>`<ellipse cx="200" cy="300" rx="190" ry="36" fill="#f6efe4"/><g transform="translate(10 110) scale(1.8)">${inn(P[5])}</g><g transform="translate(190 120) scale(1.8)">${inn(P[6])}</g>`},
{r:0.667,R:0.667,cap:'Le geste du barista',sub:'Précision et passion',bg:['#a8703d','#150a04'],b:()=>`${glow(300,120,60)}${person(190,'#4a2a1a')}<path d="M160 400V270h60v130z" fill="#c0833f"/><path d="M232 280l56-34" stroke="#4a2a1a" stroke-width="24" stroke-linecap="round"/><rect x="280" y="190" width="38" height="58" rx="7" fill="#cfd3d6"/><rect x="-100" y="330" width="700" height="300" fill="#1a0c05"/><g transform="translate(270 255) scale(.7)">${inn(P[1])}</g>`},
{r:0.692,R:0.692,cap:'La machine espresso',sub:'Chrome, vapeur et caractère',bg:['#6a3d24','#0e0602'],b:()=>`<rect x="70" y="120" width="260" height="140" rx="14" fill="#b8bcc0"/><rect x="58" y="98" width="284" height="32" rx="10" fill="#e3e6e8"/><circle cx="200" cy="180" r="26" fill="#fff"/><path d="M200 180l14-14" stroke="#a3203a" stroke-width="3"/>${[120,240].map(x=>`<rect x="${x}" y="260" width="40" height="20" fill="#6b6f73"/><rect x="${x-14}" y="276" width="68" height="10" rx="4" fill="#2a2a2a"/><g transform="translate(${x-12} 280) scale(.55)">${inn(P[0])}</g>`).join('')}<rect x="58" y="350" width="284" height="14" rx="4" fill="#1c1c1c"/>`},
{r:0.75,R:0.75,cap:'Iced coffee',sub:'Fraîcheur glacée',bg:['#d9b98a','#4a2a1a'],b:()=>`<path d="M130 100h140l-18 250q-2 14-52 14t-52-14z" fill="#fff" fill-opacity=".2" stroke="#fff" stroke-opacity=".7" stroke-width="3"/><path d="M137 170h126l-13 180q-2 12-50 12t-50-12z" fill="#6b3d22"/><path d="M137 170h126l-3 34h-120z" fill="#d9b98a"/>${[[150,150,10],[190,135,-14],[225,155,20],[170,185,-6]].map(c=>`<rect x="${c[0]}" y="${c[1]}" width="44" height="40" rx="7" fill="#fff" fill-opacity=".5" transform="rotate(${c[2]} ${c[0]+22} ${c[1]+20})"/>`).join('')}<path d="M215 50l22 160" stroke="#c0833f" stroke-width="9" stroke-linecap="round"/>`},
{r:0.66,R:0.562,cap:'Petit-déjeuner à la CM201',sub:'Croissant, café et confiture',bg:['#9a6a3e','#3a1e10'],b:()=>`<circle cx="130" cy="210" r="100" fill="#f6efe4"/><circle cx="130" cy="210" r="78" fill="#fff"/><g transform="translate(75 150) scale(.95)">${inn(P[7])}</g><circle cx="290" cy="170" r="58" fill="#f6efe4"/><circle cx="290" cy="170" r="36" fill="#fff"/><circle cx="290" cy="170" r="28" fill="#3b1d0e"/><circle cx="290" cy="170" r="16" fill="#c68a4d"/><rect x="270" y="270" width="50" height="60" rx="8" fill="#a3203a"/><rect x="270" y="262" width="50" height="14" rx="4" fill="#c0833f"/>`},
{r:0.75,R:0.75,cap:'Entre amis, autour d’un café',sub:'Le plaisir de partager',bg:['#b9803f','#1d0e07'],b:()=>`${glow(60,90,50)}${person(110,'#6b3d22')}${person(290,'#d9b98a')}<rect x="-100" y="320" width="700" height="300" fill="#2a160d"/><g transform="translate(70 285) scale(.55)">${inn(P[1])}</g><g transform="translate(255 285) scale(.55)">${inn(P[2])}</g>`},
{r:0.66,R:0.562,cap:'Un coin cosy',sub:'Ambiance chaleureuse',bg:['#7a4a2c','#150a04'],b:()=>`<path d="M60 250V120a70 70 0 0 1 140 0v130z" fill="#2a3a52"/><path d="M130 50v200M60 150h140" stroke="#150a04" stroke-width="5"/>${glow(300,110,36)}<circle cx="300" cy="110" r="20" fill="#ffd9a0"/><rect x="296" y="130" width="8" height="150" fill="#150a04"/><rect x="150" y="230" width="170" height="90" rx="26" fill="#a3203a"/><rect x="150" y="190" width="60" height="110" rx="22" fill="#8a1a30"/><rect x="-100" y="320" width="700" height="300" fill="#1a0c05"/><g transform="translate(70 235) scale(.7)">${inn(P[2])}</g>`}
];
function ph(i,p){const g=GAL[i],n=String(i+1).padStart(2,'0');
 return `<div class="ph"><svg viewBox="0 0 400 400" preserveAspectRatio="xMidYMid slice" role="img" aria-label="${g.cap}"><defs><radialGradient id="${p}b${i}" cx=".5" cy=".4" r=".9"><stop offset="0" stop-color="${g.bg[0]}"/><stop offset="1" stop-color="${g.bg[1]}"/></radialGradient><radialGradient id="${p}v${i}" cx=".5" cy=".5" r=".75"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".5"/></radialGradient></defs><rect x="-300" y="-300" width="1000" height="1000" fill="url(#${p}b${i})"/>${g.b()}<rect x="-300" y="-300" width="1000" height="1000" fill="url(#${p}v${i})"/></svg><img src="images/${n}.jpg" alt="${g.cap}" loading="lazy" onerror="this.remove()"></div>`}
const mas=$('#mas'),lb=$('#lb');let cur=0,opener=null;
mas.innerHTML=GAL.map((g,i)=>`<figure style="--r:${g.r};transition-delay:${(i%4)*90}ms" tabindex="0" role="button" aria-label="Agrandir : ${g.cap}" data-i="${i}">${ph(i,'t')}<figcaption>${g.cap}<small>${g.sub}</small></figcaption></figure>`).join('');
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
$$('#mas figure').forEach(f=>{io.observe(f);f.onclick=()=>openLb(+f.dataset.i,f);f.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();f.click()}}});
function openLb(i,from){if(from)opener=from;cur=(i+GAL.length)%GAL.length;const g=GAL[cur];$('#lbv').style.setProperty('--r',g.R||g.r);$('#lbv').innerHTML=ph(cur,'l');$('#lbc').textContent=g.cap+' — '+g.sub;lb.classList.add('open');document.body.style.overflow='hidden';window.lenis&&lenis.stop();$('#lbx').focus()}
function closeLb(){lb.classList.remove('open');document.body.style.overflow='';window.lenis&&lenis.start();if(opener)opener.focus()}
$('#lbx').onclick=closeLb;$('#lbp').onclick=()=>openLb(cur-1);$('#lbn').onclick=()=>openLb(cur+1);
lb.onclick=e=>{if(e.target===lb)closeLb()};
addEventListener('keydown',e=>{if(!lb.classList.contains('open'))return;if(e.key==='Escape')closeLb();if(e.key==='ArrowLeft')openLb(cur-1);if(e.key==='ArrowRight')openLb(cur+1)});
/* ---------- LOADER ---------- */
try{hero()}catch(e){$('#fb').style.display='block'}
let pv=0;const iv=setInterval(()=>{pv+=12+Math.random()*14;$('#pg').style.width=Math.min(pv,100)+'%';if(pv>=100){clearInterval(iv);setTimeout(()=>{$('#loader').classList.add('done');dispatchEvent(new Event('cm201:ready'))},300)}},180);
draw();
